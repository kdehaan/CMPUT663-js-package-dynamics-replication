DROP TABLE `version_query_resolutions`;
