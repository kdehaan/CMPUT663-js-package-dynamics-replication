DROP TABLE `packages`
