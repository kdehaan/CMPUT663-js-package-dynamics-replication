DROP TABLE `projects`;
