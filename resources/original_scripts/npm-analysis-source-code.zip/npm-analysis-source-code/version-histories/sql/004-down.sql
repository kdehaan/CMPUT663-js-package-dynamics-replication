DROP TABLE `project_explicit_dependencies`;
