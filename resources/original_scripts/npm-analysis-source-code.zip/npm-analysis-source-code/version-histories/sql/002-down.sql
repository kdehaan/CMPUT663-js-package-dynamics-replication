DROP TABLE `package_versions`;
